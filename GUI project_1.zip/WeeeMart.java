import java.lang.*;
import javax.swing.*;
import java.awt.*;
import javax.swing.text.*;
import java.awt.event.*; 
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;



public class WeeeMart extends JFrame implements MouseListener, ActionListener
{
	ImageIcon img;
	JLabel userLabel, passLabel, imgLabel ,textLabel,nameLabel;
	JTextField userTF , searchTF ;
	JPasswordField passPF;
	JButton loginBtn, exitBtn , DealsBtn , BrandBtn , CartBtn, SignBtn, SearchBtn;
	JRadioButton r1, r2, r3;
	JCheckBox c1, c2, c3, c4,c5,c6,c7;
	ButtonGroup bg1;
	JComboBox combo , combo1;
	JPanel panel;
	Color myColor;
    Font myFont, myFont1,myFont2,myFont3,myFont4,myFont5;
	private JTextArea cartArea;
    private JLabel totalLabel;
	private JFrame frame;              // Main frame for the application
    private JTextField num1Field, num2Field;  // Text fields for entering numbers
    private JLabel resultLabel;         // Label to display the result of the calculation
    private JButton addButton, subtractButton;  // Buttons for addition and subtraction
    private FileWriter writer; 
	private JSpinner qty1,qty2,qty3,qty4,qty5,qty6,qty7;
	private int totalPrice = 0;
	private JTextField priceField;
    private JTextField quantityField;
	private JButton calculateButton;


public WeeeMart()
{
  super("Weee Mart");
  this.setSize(1050, 1100);   
  this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

  
    myColor = new Color(175,225,175);
	myFont = new Font("Calibri", Font.BOLD, 25);
	myFont1 = new Font("Broadway", Font.BOLD, 20);
	myFont2 = new Font("Congenial SemiBold", Font.BOLD, 18);
	myFont3 = new Font("Calibri", Font.BOLD, 25);
    myFont4= new Font ("Calibri", Font.PLAIN, 10);
	myFont5= new Font ("Calibri", Font.PLAIN, 16);


	ImageIcon weeemartimg = new ImageIcon("Images/b.jpg");
	//ImageIcon backgroundimg = new ImageIcon("Images/sup.jpg"); 	

   panel = new JPanel() {
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        g.setColor(new Color(193, 225, 193));
        g.fillRect(0, 455, getWidth(), getHeight());
        g.drawImage(weeemartimg.getImage(), 10, 60, 990, 280, this);        
		
		g.fillRect(0, 0, getWidth(), getHeight());
        g.drawImage(weeemartimg.getImage(), 10, 60, 990, 280, this);
		
		g.setColor(new Color(255, 255, 255)); // white
        g.fillRect(0,0, getWidth(),542);

	 //g.drawImage(backgroundimg.getImage(), 10, 365,200,190 , this);
  
	 g.drawImage(weeemartimg.getImage(), 0,50, getWidth(),250, this);
   }
};
panel.setLayout(null);

	
	cartArea = new JTextArea();
    cartArea.setBounds(30, 140, 200, 100);
    cartArea.setEditable(false);
    cartArea.setBorder(BorderFactory.createTitledBorder("Cart"));
	cartArea.setBackground(Color.ORANGE); 
	cartArea.setForeground(Color.WHITE);
    panel.add(cartArea);
	
    JScrollPane scrollPane = new JScrollPane(cartArea);
    scrollPane.setBounds(30, 140, 200, 100);
    panel.add(scrollPane);

    totalLabel = new JLabel("Total: ৳0");
    totalLabel.setBounds(30, 250, 200, 30);
    totalLabel.setFont(myFont4);
    totalLabel.setOpaque(true); 
    totalLabel.setBackground(Color.ORANGE); 
    totalLabel.setForeground(Color.BLACK);	
    panel.add(totalLabel);


	userLabel = new JLabel("User Name : ");
	userLabel.setBounds(660, 70, 120, 30);
	userLabel.setFont(myFont2);
	userLabel.setForeground(Color.WHITE);
	panel.add(userLabel);

	userTF = new JTextField();
	userTF.setBounds(810,70, 100, 30);
	panel.add(userTF);
		
    passLabel = new JLabel("Password : ");
	passLabel.setBounds(660, 120, 110, 30);
	passLabel.setForeground(Color.WHITE);
	passLabel.setFont(myFont2);
	panel.add(passLabel);
	
	passPF = new JPasswordField();
	passPF.setBounds(810, 120, 100, 30);
	panel.add(passPF);
	
	nameLabel = new JLabel("WEEEMART ");
	nameLabel.setBounds(10,15, 150, 30);
	nameLabel.setFont(myFont1);
	nameLabel.setForeground(Color.RED);
	panel.add(nameLabel);
	

	
	loginBtn = new JButton("Login");
	loginBtn.setBounds(700, 205, 80, 30);
	Color neonBlue = new Color(31, 81, 255); 
    loginBtn.setBackground(neonBlue);
	loginBtn.setForeground(Color.WHITE);
	loginBtn.addMouseListener(this);
	loginBtn.addActionListener(this);
	panel.add(loginBtn);

		
	exitBtn = new JButton("Exit");
	exitBtn.setBounds(790, 205, 80, 30);
	Color neonblue = new Color(31, 81, 255); 
    exitBtn.setBackground(neonblue);
	exitBtn.setForeground(Color.WHITE);
	exitBtn.addMouseListener(this);
	exitBtn.addActionListener(this);
	panel.add(exitBtn);

	
    r1 = new JRadioButton("Remember Password");
    r1.setBounds(640, 155, 150, 20); 
    r1.setForeground(Color.RED);
    panel.add(r1); 

    r2 = new JRadioButton("Forget Password");
    r2.setBounds(830, 155, 150, 20); 
    r2.setForeground(Color.RED);
    panel.add(r2);

// Now add them to the ButtonGroup
    bg1 = new ButtonGroup();
    bg1.add(r1); 
    bg1.add(r2);

	DealsBtn = new JButton("Great Deals");
	DealsBtn.setBounds(640,15,120,30);
    DealsBtn.setBackground(Color.RED);
    DealsBtn.setForeground(Color.WHITE); 
	panel.add(DealsBtn);
	
	String items1[] = {"Brand","Uniliver","Faber Castle","Walton","Kazi Farms"};
	combo1 = new JComboBox(items1);
	combo1.setBounds(30, 100, 100, 30);
	combo1.setBackground(Color.WHITE);
	combo1.setForeground(Color.BLACK); 
	panel.add(combo1);
	
	searchTF = new JTextField();
	searchTF.setBounds(250, 15, 270, 30);
	panel.add(searchTF);
	
	SearchBtn = new JButton("Search");
	SearchBtn.setBounds(540, 15, 90, 30);
	Color forestgreen = new Color(34, 139, 34); 
    SearchBtn.setBackground(forestgreen);
	SearchBtn.setForeground(Color.WHITE);
	SearchBtn.addMouseListener(this);
	SearchBtn.addActionListener(this);
	panel.add(SearchBtn);

	
	SignBtn = new JButton("Sign in");
	SignBtn.setBounds(860,15,100,30);
	Color skyblue = new Color(31, 81, 255); 
    SignBtn.setBackground(skyblue);
	SignBtn.setForeground(Color.WHITE);
	SignBtn.addMouseListener(this);
	SignBtn.addActionListener(this);
	panel.add(SignBtn);

	
	CartBtn = new JButton("Cart");
	CartBtn.setBounds(760, 15, 100, 30);
	CartBtn.setBackground(Color.WHITE);
    CartBtn.setBackground(Color.ORANGE);
	CartBtn.setForeground(Color.WHITE);
	panel.add(CartBtn);
	
	textLabel = new JLabel("Recommended items");
	textLabel.setBounds(30, 535, 400, 40);
	textLabel.setFont(myFont);
	textLabel.setForeground(Color.RED);
	panel.add(textLabel);
	
	textLabel = new JLabel("Summer's Craving");
	textLabel.setBounds(35, 295, 200, 40);
	textLabel.setFont(myFont3);
	textLabel.setForeground(Color.RED);
	panel.add(textLabel);
	
	img = new ImageIcon("Images/frutika.jpg");
	imgLabel = new JLabel(img);
	imgLabel.setBounds(285, 301,185,185);
	panel.add(imgLabel);
	
	textLabel = new JLabel("Frutika Red Grape Fruit Drink-250ml");
	textLabel.setBounds(280,475, 230, 40);
	textLabel.setForeground(Color.BLACK);
	//textLabel.setFont(myFont4);
	panel.add(textLabel);
	
	img = new ImageIcon("Images/sup.jpg");
	imgLabel = new JLabel(img);
	imgLabel.setBounds(35,325,200,200);
	panel.add(imgLabel);
   
   textLabel = new JLabel("(৳26 Per Piece)");
    textLabel.setBounds(330, 488, 350, 40);
    //textLabel.setFont(myFont5);
    panel.add(textLabel);
	
		
	c6 = new JCheckBox("Add to cart");
	c6.setBounds(315,517, 100, 20);
	c6.setBackground(Color.YELLOW); 
	panel.add(c6);
	
	img = new ImageIcon("Images/tang.jpg");
	imgLabel = new JLabel(img);
	imgLabel.setBounds(510, 301,185,185);
	panel.add(imgLabel);
	
	textLabel = new JLabel("Tang Powder Drink Orange 750gm");
	textLabel.setBounds(535,475, 150, 40);
	textLabel.setForeground(Color.BLACK);
	panel.add(textLabel);
	
	
    textLabel = new JLabel("(৳260 per piece)");
    textLabel.setBounds(580, 488, 350, 40);
    //textLabel.setFont(myFont5);
    panel.add(textLabel);
	
		
	c5 = new JCheckBox("Add to cart");
	c5.setBounds(555,517, 100, 20);
	c5.setBackground(Color.YELLOW); 
	panel.add(c5);
		
	img = new ImageIcon("Images/ice.jpg");
	imgLabel = new JLabel(img);
	imgLabel.setBounds(735, 301,186,186);
	panel.add(imgLabel);
	
	textLabel = new JLabel("Savoy Kheer Malai Premium Cup");
	textLabel.setBounds(780,475,150, 40);
	textLabel.setForeground(Color.BLACK);
	panel.add(textLabel);
	
	
    textLabel = new JLabel("(৳70 per piece)");
    textLabel.setBounds(820,488, 350, 40);
    //textLabel.setFont(myFont5);
    panel.add(textLabel);
			
	c7 = new JCheckBox("Add to cart");
	c7.setBounds(795,517, 100, 20);
	c7.setBackground(Color.YELLOW); 
	panel.add(c7);
	
	
	img = new ImageIcon("Images/a.jpg");
	imgLabel = new JLabel(img);
	imgLabel.setBounds(30,500,200,301);
	panel.add(imgLabel);
	
	img = new ImageIcon("Images/egg.jpg");
	imgLabel = new JLabel(img);
	imgLabel.setBounds(240,545,200,200);
	panel.add(imgLabel);
	
	textLabel = new JLabel("Egg (৳12 per piece)");
	textLabel.setBounds(275, 720, 200, 40);
	textLabel.setForeground(Color.WHITE);
	panel.add(textLabel);
	
	c1 = new JCheckBox("Add to cart");
	c1.setBounds(255,750, 100, 20);
	c1.setBackground(Color.YELLOW); 
	panel.add(c1);
	
	
	img = new ImageIcon("Images/tresme.jpg");
	imgLabel = new JLabel(img);
	imgLabel.setBounds(660,558,175,175);
	panel.add(imgLabel);
		
	textLabel = new JLabel("Tresemme (৳400)");
	textLabel.setBounds(690, 720, 200, 40);
	textLabel.setForeground(Color.WHITE);
	panel.add(textLabel);
	
	c2 = new JCheckBox("Add to cart");
	c2.setBounds(690, 750 , 100, 20);
	c2.setBackground(Color.YELLOW);
	panel.add(c2);
		
	img = new ImageIcon("Images/Napa.jpg");
	imgLabel = new JLabel(img);
	imgLabel.setBounds(850,558,175,175);
	panel.add(imgLabel);
		
	textLabel = new JLabel("Napa-Extra (৳40)");
	textLabel.setBounds(875, 720, 200, 40);
	textLabel.setForeground(Color.WHITE);
	panel.add(textLabel);
	
	c3 = new JCheckBox("Add to cart");
	c3.setBounds(875, 750 , 100, 20);
	c3.setBackground(Color.YELLOW);
	panel.add(c3);
  
    img = new ImageIcon("Images/blender.jpg");
	imgLabel = new JLabel(img);
	imgLabel.setBounds(445,546,200,200);
	panel.add(imgLabel);
		
	textLabel = new JLabel("Walton Juicer Machine(৳1000)");
	textLabel.setBounds(460, 720, 250, 40);
	textLabel.setForeground(Color.WHITE);
	panel.add(textLabel);
	
	c4 = new JCheckBox("Add to cart");
	c4.setBounds(460, 750 , 100, 20);
	c4.setBackground(Color.YELLOW);
	panel.add(c4);
	
	 // Initialize spinners with default models (min=0, max=100, step=1, initial=1)
        qty1 = new JSpinner(new SpinnerNumberModel(1, 0, 100, 1));
        qty1.setBounds(360, 750, 50, 20);
        panel.add(qty1);

        qty2 = new JSpinner(new SpinnerNumberModel(1, 0, 100, 1));
        qty2.setBounds(795, 750, 50, 20);
        panel.add(qty2);

        qty3 = new JSpinner(new SpinnerNumberModel(1, 0, 100, 1));
        qty3.setBounds(980, 750, 50, 20);
        panel.add(qty3);

        qty4 = new JSpinner(new SpinnerNumberModel(1, 0, 100, 1));
        qty4.setBounds(565, 750, 50, 20);
        panel.add(qty4);

        qty5 = new JSpinner(new SpinnerNumberModel(1, 0, 100, 1));
        qty5.setBounds(660, 517, 50, 20);
        panel.add(qty5);

        qty6 = new JSpinner(new SpinnerNumberModel(1, 0, 100, 1));
        qty6.setBounds(420,517, 50, 20);
        panel.add(qty6);

        qty7 = new JSpinner(new SpinnerNumberModel(1, 0, 100, 1));
        qty7.setBounds(900, 517, 50, 20);
        panel.add(qty7);

        // Add listeners to checkboxes and spinners
        c1.addItemListener(e -> updateCart());
        c2.addItemListener(e -> updateCart());
        c3.addItemListener(e -> updateCart());
        c4.addItemListener(e -> updateCart());
        c5.addItemListener(e -> updateCart());
        c6.addItemListener(e -> updateCart());
        c7.addItemListener(e -> updateCart());

        qty1.addChangeListener(e -> updateCart());
        qty2.addChangeListener(e -> updateCart());
        qty3.addChangeListener(e -> updateCart());
        qty4.addChangeListener(e -> updateCart());
        qty5.addChangeListener(e -> updateCart());
        qty6.addChangeListener(e -> updateCart());
        qty7.addChangeListener(e -> updateCart());
	
    String items[] = {"Category","Grocery","Medicine","Food","Makeup","Stationary","Appliance"};
	combo = new JComboBox(items);
	combo.setBounds(30, 70, 100, 30);
	combo.setBackground(Color.WHITE); 
	combo.setForeground(Color.BLACK); 
	panel.add(combo);
	
 setupFileWriter();
  

   calculateButton = new JButton("Purchase");
   calculateButton.setBounds(250, 250, 150, 30); // You need to set bounds since you use null layout
 calculateButton.addActionListener(e -> {
    try {
        // Open writer in append mode
        FileWriter writer = new FileWriter("cart.txt", true);
        
        writer.write("Purchase Details:\n");
        if (c1.isSelected()) {
            int price = 12;
            int qty = (Integer) qty1.getValue();
            writer.write("Egg x" + qty + " - ৳" + (price * qty) + "\n");
        }
        if (c2.isSelected()) {
            int price = 400;
            int qty = (Integer) qty2.getValue();
            writer.write("Tresemme x" + qty + " - ৳" + (price * qty) + "\n");
        }
        if (c3.isSelected()) {
            int price = 40;
            int qty = (Integer) qty3.getValue();
            writer.write("Napa-Extra x" + qty + " - ৳" + (price * qty) + "\n");
        }
        if (c4.isSelected()) {
            int price = 1000;
            int qty = (Integer) qty4.getValue();
            writer.write("Walton Juicer Machine x" + qty + " - ৳" + (price * qty) + "\n");
        }
        if (c5.isSelected()) {
            int price = 260;
            int qty = (Integer) qty5.getValue();
            writer.write("Tang Powder Drink Orange 750gm x" + qty + " - ৳" + (price * qty) + "\n");
        }
        if (c6.isSelected()) {
            int price = 26;
            int qty = (Integer) qty6.getValue();
            writer.write("Frutika Red Grape Fruit Drink-250ml x" + qty + " - ৳" + (price * qty) + "\n");
        }
        if (c7.isSelected()) {
            int price = 70;
            int qty = (Integer) qty7.getValue();
            writer.write("Savoy Kheer Malai Premium Cup x" + qty + " - ৳" + (price * qty) + "\n");
        }
        
        writer.write("Total: ৳" + totalPrice + "\n");
        writer.write("---------------------------\n");
        
        writer.flush();
        writer.close();
        
        JOptionPane.showMessageDialog(this, "Purchase saved successfully!");
    } catch (IOException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error saving purchase.");
    }
});

panel.add(calculateButton);


   this.add(panel);
   this.setVisible(true);
}

private void updateCart() {
    try {
        cartArea.setText("");
        totalPrice = 0;

        if (c1.isSelected()) {
            int price = 12;
            int qty = (Integer) qty1.getValue();
            cartArea.append("Egg x" + qty + " - ৳" + (price * qty) + "\n");
            totalPrice += price * qty;
        }
        if (c2.isSelected()) {
            int price = 400;
            int qty = (Integer) qty2.getValue();
            cartArea.append("Tresemme x" + qty + " - ৳" + (price * qty) + "\n");
            totalPrice += price * qty;
        }
        if (c3.isSelected()) {
            int price = 40;  // corrected price
            int qty = (Integer) qty3.getValue();
            cartArea.append("Napa-Extra x" + qty + " - ৳" + (price * qty) + "\n");
            totalPrice += price * qty;
        }
        if (c4.isSelected()) {
            int price = 1000;  // corrected price
            int qty = (Integer) qty4.getValue();
            cartArea.append("Walton Juicer Machine x" + qty + " - ৳" + (price * qty) + "\n");
            totalPrice += price * qty;
        }
        if (c5.isSelected()) {
            int price = 260;
            int qty = (Integer) qty5.getValue();
            cartArea.append("Tang Powder Drink Orange 750gm x" + qty + " - ৳" + (price * qty) + "\n");
            totalPrice += price * qty;
        }
        if (c6.isSelected()) {
            int price = 26;
            int qty = (Integer) qty6.getValue();
            cartArea.append("Frutika Red Grape Fruit Drink-250ml x" + qty + " - ৳" + (price * qty) + "\n");
            totalPrice += price * qty;
        }
        if (c7.isSelected()) {
            int price = 70;
            int qty = (Integer) qty7.getValue();
            cartArea.append("Savoy Kheer Malai Premium Cup x" + qty + " - ৳" + (price * qty) + "\n");
            totalPrice += price * qty;
        }

        totalLabel.setText("Total: ৳" + totalPrice);
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
    }
}
private void setupFileWriter() {
    try {
        writer = new FileWriter("cart.txt", true);  // append mode
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Could not open file for writing.");
    }
}


 private void updateTotal() {
    totalLabel.setText("Total: ৳" + totalPrice);
}

private void removeFromCart(String item) {
    String content = cartArea.getText();
    content = content.replace(item + "\n", "");
    cartArea.setText(content);

}


    public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
 
 public void mouseEntered(MouseEvent me)
	{
		if(me.getSource() == loginBtn)
		{
			loginBtn.setBackground(Color.BLUE);
			loginBtn.setForeground(Color.WHITE);
		}
		else if(me.getSource() == exitBtn)
		{
			exitBtn.setBackground(Color.BLUE);
			exitBtn.setForeground(Color.WHITE);
		}
		else
		{
			
		}
	}
public void mouseExited(MouseEvent me)
	{
		if(me.getSource() == loginBtn)
		{
			loginBtn.setBackground(Color.GREEN);
			loginBtn.setForeground(Color.BLACK);
		}
		else if(me.getSource() == exitBtn)
		{
			exitBtn.setBackground(Color.RED);
			exitBtn.setForeground(Color.BLACK);
		}
		else
		{
			
		}
	}
public void actionPerformed(ActionEvent ae)
	{
		String command = ae.getActionCommand();
		
		if(loginBtn.getText().equals(command))
		{
			JOptionPane.showMessageDialog(this, "HAPPY SHOPPING ");
		}
		else if(exitBtn.getText().equals(command))
		{
			System.exit(0);
		}
		else
		{
			
		}
		
	}

}

	


