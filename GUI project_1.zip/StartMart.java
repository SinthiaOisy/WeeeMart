import java.lang.*;
import javax.swing.SwingUtilities;


public class StartMart {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            WeeeMart we = new WeeeMart();
            we.setVisible(true);

        });
    }
}
