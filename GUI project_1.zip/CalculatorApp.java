import javax.swing.*;  // Import Swing package for GUI components
import java.awt.*;      // Import AWT for Layout and Event handling
import java.awt.event.*; // Import AWT event handling for button clicks
import java.io.*;       // Import Java IO for file handling

public class CalculatorApp {

    // Frame setup (Main GUI components)
    private JFrame frame;              // Main frame for the application
    private JTextField num1Field, num2Field;  // Text fields for entering numbers
    private JLabel resultLabel;         // Label to display the result of the calculation
    private JButton addButton, subtractButton;  // Buttons for addition and subtraction
    private FileWriter writer;         // File writer to store results in a text file

    public static void main(String[] args) {
        // Ensuring the GUI is created in the Event Dispatch Thread for thread safety
        SwingUtilities.invokeLater(() -> {
            try {
                CalculatorApp window = new CalculatorApp(); // Create a new instance of the app
                window.frame.setVisible(true); // Display the frame
            } catch (Exception e) {
                e.printStackTrace(); // Handle any exceptions during initialization
            }
        });
    }

    public CalculatorApp() {
        initialize();  // Initialize the GUI components
        setupFileWriter();  // Set up the file writer to save results
    }

    private void initialize() {
        // Frame setup: Configure the main window
        frame = new JFrame(); // Create the main frame
        frame.setBounds(100, 100, 400, 300); // Set the size and position of the frame
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Set default close operation
        frame.getContentPane().setLayout(new GridLayout(5, 2)); // Set grid layout for the frame

        // Number fields for input
        num1Field = new JTextField(); // Create a text field for the first number
        num1Field.setBackground(Color.CYAN); // Set background color
        num1Field.setFont(new Font("Arial", Font.PLAIN, 16)); // Set font style and size
        frame.getContentPane().add(new JLabel("Enter Number 1:")); // Label for the first number
        frame.getContentPane().add(num1Field); // Add the text field to the frame

        num2Field = new JTextField(); // Create a text field for the second number
        num2Field.setBackground(Color.CYAN); // Set background color
        num2Field.setFont(new Font("Arial", Font.PLAIN, 16)); // Set font style and size
        frame.getContentPane().add(new JLabel("Enter Number 2:")); // Label for the second number
        frame.getContentPane().add(num2Field); // Add the text field to the frame

        // Buttons for operations (addition and subtraction)
        addButton = new JButton("Add"); // Create the 'Add' button
        addButton.setBackground(Color.GREEN); // Set background color
        addButton.setFont(new Font("Arial", Font.PLAIN, 16)); // Set font style and size
        frame.getContentPane().add(addButton); // Add the 'Add' button to the frame

        subtractButton = new JButton("Subtract"); // Create the 'Subtract' button
        subtractButton.setBackground(Color.RED); // Set background color
        subtractButton.setFont(new Font("Arial", Font.PLAIN, 16)); // Set font style and size
        frame.getContentPane().add(subtractButton); // Add the 'Subtract' button to the frame

        // Result Label: To display the result of the calculation
        resultLabel = new JLabel("Result: "); // Create the result label
        resultLabel.setFont(new Font("Arial", Font.BOLD, 18)); // Set bold font style
        resultLabel.setForeground(Color.BLUE); // Set text color
        frame.getContentPane().add(resultLabel); // Add the result label to the frame

        // Action listeners for the buttons
        addButton.addActionListener(new ActionListener() { // When 'Add' button is clicked
            @Override
            public void actionPerformed(ActionEvent e) {
                performCalculation("add"); // Perform the addition calculation
            }
        });

        subtractButton.addActionListener(new ActionListener() { // When 'Subtract' button is clicked
            @Override
            public void actionPerformed(ActionEvent e) {
                performCalculation("subtract"); // Perform the subtraction calculation
            }
        });
    }

    private void setupFileWriter() {
        try {
            // Set up the file writer to store results in a text file
            File file = new File("calculator_history.txt"); // Specify the file name
            if (!file.exists()) {
                file.createNewFile(); // If file doesn't exist, create a new one
            }
            writer = new FileWriter(file, true); // Open the file in append mode
        } catch (IOException e) {
            e.printStackTrace(); // Handle any I/O errors
        }
    }

    private void performCalculation(String operation) {
        try {
            // Read the values entered in the text fields
            double num1 = Double.parseDouble(num1Field.getText()); // Convert first number to double
            double num2 = Double.parseDouble(num2Field.getText()); // Convert second number to double
            double result = 0; // Initialize result variable
            String operationStr = ""; // String to store the operation type

            // Perform the required operation (addition or subtraction)
            if (operation.equals("add")) {
                result = num1 + num2; // Perform addition
                operationStr = "Addition"; // Set operation type to "Addition"
            } else if (operation.equals("subtract")) {
                result = num1 - num2; // Perform subtraction
                operationStr = "Subtraction"; // Set operation type to "Subtraction"
            }

            // Display the result in the result label
            resultLabel.setText("Result: " + result);

            // Write the operation and result to the text file
            writer.write(operationStr + ": " + num1 + " and " + num2 + " = " + result + "\n");
            writer.flush(); // Ensure the data is written to the file

        } catch (NumberFormatException e) {
            // If invalid numbers are entered, show an error message
            JOptionPane.showMessageDialog(frame, "Please enter valid numbers.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (IOException e) {
            e.printStackTrace(); // Handle any I/O errors during file writing
        }
    }
}
